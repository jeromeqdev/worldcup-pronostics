-- ============================================================
-- WORLD CUP PRONOSTICS - Schéma Supabase
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- TABLE: profiles (extension de auth.users)
-- ============================================================
CREATE TABLE public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  pseudo TEXT NOT NULL UNIQUE,
  avatar_url TEXT,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index pseudo pour les requêtes de classement
CREATE INDEX idx_profiles_pseudo ON public.profiles(pseudo);

-- ============================================================
-- TABLE: groups (groupes de la phase de poules)
-- ============================================================
CREATE TABLE public.groups (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE, -- "A", "B", ..., "H"
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: teams (équipes)
-- ============================================================
CREATE TABLE public.teams (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  country_code TEXT NOT NULL UNIQUE, -- ISO 3166-1 alpha-2 ex: "FR", "BR"
  flag_url TEXT, -- URL du drapeau (ex: via flagcdn.com)
  group_id UUID REFERENCES public.groups(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_teams_country_code ON public.teams(country_code);

-- ============================================================
-- TABLE: stadiums (stades)
-- ============================================================
CREATE TABLE public.stadiums (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  city TEXT NOT NULL,
  country TEXT NOT NULL,
  capacity INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: matches
-- ============================================================
CREATE TYPE match_phase AS ENUM (
  'group',        -- Phase de groupes
  'round_of_16',  -- Huitièmes
  'quarter_final',-- Quarts
  'semi_final',   -- Demi-finales
  'third_place',  -- 3e place
  'final'         -- Finale
);

CREATE TYPE match_status AS ENUM (
  'upcoming',   -- À venir
  'live',       -- En cours
  'finished'    -- Terminé
);

CREATE TABLE public.matches (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  match_number INTEGER NOT NULL UNIQUE, -- Numéro officiel du match
  phase match_phase NOT NULL DEFAULT 'group',
  group_id UUID REFERENCES public.groups(id), -- NULL pour phases éliminatoires
  home_team_id UUID REFERENCES public.teams(id),
  away_team_id UUID REFERENCES public.teams(id),
  stadium_id UUID REFERENCES public.stadiums(id),
  kickoff_time TIMESTAMPTZ NOT NULL,
  status match_status DEFAULT 'upcoming',
  -- Résultats officiels (NULL jusqu'à la fin du match)
  home_score INTEGER,
  away_score INTEGER,
  -- Pour les phases éliminatoires : résultat après prolongations/tirs au but
  home_score_extra INTEGER,
  away_score_extra INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT different_teams CHECK (home_team_id != away_team_id),
  CONSTRAINT valid_scores CHECK (
    (home_score IS NULL AND away_score IS NULL) OR
    (home_score >= 0 AND away_score >= 0)
  )
);

CREATE INDEX idx_matches_kickoff ON public.matches(kickoff_time);
CREATE INDEX idx_matches_status ON public.matches(status);
CREATE INDEX idx_matches_phase ON public.matches(phase);

-- ============================================================
-- TABLE: predictions (pronostics)
-- ============================================================
CREATE TABLE public.predictions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  match_id UUID REFERENCES public.matches(id) ON DELETE CASCADE NOT NULL,
  home_score INTEGER NOT NULL CHECK (home_score >= 0),
  away_score INTEGER NOT NULL CHECK (away_score >= 0),
  -- Calculé automatiquement à la création
  predicted_winner TEXT, -- 'home', 'away', 'draw'
  -- Points attribués après calcul (NULL avant résultat officiel)
  points INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  -- Un seul pronostic par utilisateur par match
  UNIQUE(user_id, match_id)
);

CREATE INDEX idx_predictions_user ON public.predictions(user_id);
CREATE INDEX idx_predictions_match ON public.predictions(match_id);

-- ============================================================
-- TABLE: rankings (classement - vue matérialisée en table)
-- ============================================================
CREATE TABLE public.rankings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL UNIQUE,
  total_points INTEGER DEFAULT 0,
  exact_scores INTEGER DEFAULT 0,   -- Nombre de scores exacts (5 pts)
  correct_results INTEGER DEFAULT 0, -- Nombre de bons résultats (3 pts)
  correct_draws INTEGER DEFAULT 0,   -- Bons matchs nuls (2 pts)
  predictions_count INTEGER DEFAULT 0,
  rank INTEGER,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_rankings_points ON public.rankings(total_points DESC, exact_scores DESC);

-- ============================================================
-- FONCTIONS & TRIGGERS
-- ============================================================

-- Trigger: créer automatiquement un profil rankings à l'inscription
CREATE OR REPLACE FUNCTION create_ranking_on_profile()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.rankings (user_id) VALUES (NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_profile_created
  AFTER INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION create_ranking_on_profile();

-- Fonction: calculer le vainqueur prédit
CREATE OR REPLACE FUNCTION get_predicted_winner(home INTEGER, away INTEGER)
RETURNS TEXT AS $$
BEGIN
  IF home > away THEN RETURN 'home';
  ELSIF away > home THEN RETURN 'away';
  ELSE RETURN 'draw';
  END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Trigger: calculer predicted_winner avant insertion pronostic
CREATE OR REPLACE FUNCTION set_predicted_winner()
RETURNS TRIGGER AS $$
BEGIN
  NEW.predicted_winner := get_predicted_winner(NEW.home_score, NEW.away_score);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER before_prediction_insert
  BEFORE INSERT OR UPDATE ON public.predictions
  FOR EACH ROW EXECUTE FUNCTION set_predicted_winner();

-- Fonction: calculer les points d'un pronostic
CREATE OR REPLACE FUNCTION calculate_prediction_points(
  p_home_pred INTEGER,
  p_away_pred INTEGER,
  p_home_actual INTEGER,
  p_away_actual INTEGER
) RETURNS INTEGER AS $$
DECLARE
  actual_winner TEXT;
  predicted_winner TEXT;
BEGIN
  IF p_home_actual IS NULL OR p_away_actual IS NULL THEN
    RETURN NULL; -- Match pas encore joué
  END IF;

  actual_winner := get_predicted_winner(p_home_actual, p_away_actual);
  predicted_winner := get_predicted_winner(p_home_pred, p_away_pred);

  -- Score exact
  IF p_home_pred = p_home_actual AND p_away_pred = p_away_actual THEN
    RETURN 5;
  END IF;

  -- Bon match nul (score incorrect)
  IF actual_winner = 'draw' AND predicted_winner = 'draw' THEN
    RETURN 2;
  END IF;

  -- Bon vainqueur
  IF actual_winner = predicted_winner THEN
    RETURN 3;
  END IF;

  -- Mauvais résultat
  RETURN 0;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Fonction: recalculer classement complet
CREATE OR REPLACE FUNCTION recalculate_rankings()
RETURNS void AS $$
BEGIN
  -- Mettre à jour les points de chaque prédiction
  UPDATE public.predictions p
  SET points = calculate_prediction_points(
    p.home_score, p.away_score,
    m.home_score, m.away_score
  )
  FROM public.matches m
  WHERE p.match_id = m.id
    AND m.status = 'finished'
    AND m.home_score IS NOT NULL;

  -- Recalculer le classement
  UPDATE public.rankings r
  SET
    total_points = COALESCE(agg.total_points, 0),
    exact_scores = COALESCE(agg.exact_scores, 0),
    correct_results = COALESCE(agg.correct_results, 0),
    correct_draws = COALESCE(agg.correct_draws, 0),
    predictions_count = COALESCE(agg.predictions_count, 0),
    updated_at = NOW()
  FROM (
    SELECT
      p.user_id,
      SUM(COALESCE(p.points, 0)) AS total_points,
      COUNT(*) FILTER (WHERE p.points = 5) AS exact_scores,
      COUNT(*) FILTER (WHERE p.points = 3) AS correct_results,
      COUNT(*) FILTER (WHERE p.points = 2) AS correct_draws,
      COUNT(*) AS predictions_count
    FROM public.predictions p
    GROUP BY p.user_id
  ) agg
  WHERE r.user_id = agg.user_id;

  -- Mettre à jour les rangs
  WITH ranked AS (
    SELECT user_id,
      ROW_NUMBER() OVER (
        ORDER BY total_points DESC, exact_scores DESC, correct_results DESC
      ) AS new_rank
    FROM public.rankings
  )
  UPDATE public.rankings r
  SET rank = ranked.new_rank
  FROM ranked
  WHERE r.user_id = ranked.user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger: recalculer auto quand résultat officiel saisi
CREATE OR REPLACE FUNCTION trigger_recalculate_on_result()
RETURNS TRIGGER AS $$
BEGIN
  IF (NEW.status = 'finished' AND OLD.status != 'finished')
     OR (NEW.home_score IS DISTINCT FROM OLD.home_score)
     OR (NEW.away_score IS DISTINCT FROM OLD.away_score) THEN
    PERFORM recalculate_rankings();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_match_result_update
  AFTER UPDATE ON public.matches
  FOR EACH ROW EXECUTE FUNCTION trigger_recalculate_on_result();

-- Mise à jour automatique updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_matches_updated_at BEFORE UPDATE ON public.matches
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_predictions_updated_at BEFORE UPDATE ON public.predictions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rankings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stadiums ENABLE ROW LEVEL SECURITY;

-- Profiles: lecture publique, écriture propre profil
CREATE POLICY "profiles_select_all" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "profiles_admin_all" ON public.profiles FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- Matches: lecture publique, écriture admin seulement
CREATE POLICY "matches_select_all" ON public.matches FOR SELECT USING (true);
CREATE POLICY "matches_admin_write" ON public.matches FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);

-- Predictions: lecture publique, écriture propre avant coup d'envoi
CREATE POLICY "predictions_select_all" ON public.predictions FOR SELECT USING (true);
CREATE POLICY "predictions_insert_own" ON public.predictions FOR INSERT WITH CHECK (
  auth.uid() = user_id AND
  EXISTS (
    SELECT 1 FROM public.matches
    WHERE id = match_id AND kickoff_time > NOW() AND status = 'upcoming'
  )
);
CREATE POLICY "predictions_update_own" ON public.predictions FOR UPDATE USING (
  auth.uid() = user_id AND
  EXISTS (
    SELECT 1 FROM public.matches
    WHERE id = match_id AND kickoff_time > NOW() AND status = 'upcoming'
  )
);

-- Rankings: lecture publique
CREATE POLICY "rankings_select_all" ON public.rankings FOR SELECT USING (true);

-- Teams, groups, stadiums: lecture publique
CREATE POLICY "teams_select_all" ON public.teams FOR SELECT USING (true);
CREATE POLICY "teams_admin_write" ON public.teams FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true)
);
CREATE POLICY "groups_select_all" ON public.groups FOR SELECT USING (true);
CREATE POLICY "stadiums_select_all" ON public.stadiums FOR SELECT USING (true);

-- ============================================================
-- DONNÉES D'EXEMPLE: Coupe du Monde 2026
-- ============================================================

-- Groupes
INSERT INTO public.groups (name) VALUES
  ('A'), ('B'), ('C'), ('D'), ('E'), ('F'), ('G'), ('H'),
  ('I'), ('J'), ('K'), ('L');

-- Quelques équipes exemple (à compléter avec les 48 équipes qualifiées)
INSERT INTO public.teams (name, country_code, flag_url, group_id) VALUES
  ('France', 'FR', 'https://flagcdn.com/fr.svg', (SELECT id FROM public.groups WHERE name='A')),
  ('Brésil', 'BR', 'https://flagcdn.com/br.svg', (SELECT id FROM public.groups WHERE name='A')),
  ('Argentine', 'AR', 'https://flagcdn.com/ar.svg', (SELECT id FROM public.groups WHERE name='B')),
  ('Espagne', 'ES', 'https://flagcdn.com/es.svg', (SELECT id FROM public.groups WHERE name='B')),
  ('Angleterre', 'GB-ENG', 'https://flagcdn.com/gb-eng.svg', (SELECT id FROM public.groups WHERE name='C')),
  ('Portugal', 'PT', 'https://flagcdn.com/pt.svg', (SELECT id FROM public.groups WHERE name='C')),
  ('Allemagne', 'DE', 'https://flagcdn.com/de.svg', (SELECT id FROM public.groups WHERE name='D')),
  ('Pays-Bas', 'NL', 'https://flagcdn.com/nl.svg', (SELECT id FROM public.groups WHERE name='D')),
  ('Belgique', 'BE', 'https://flagcdn.com/be.svg', (SELECT id FROM public.groups WHERE name='E')),
  ('Italie', 'IT', 'https://flagcdn.com/it.svg', (SELECT id FROM public.groups WHERE name='E')),
  ('Maroc', 'MA', 'https://flagcdn.com/ma.svg', (SELECT id FROM public.groups WHERE name='F')),
  ('Sénégal', 'SN', 'https://flagcdn.com/sn.svg', (SELECT id FROM public.groups WHERE name='F')),
  ('Japon', 'JP', 'https://flagcdn.com/jp.svg', (SELECT id FROM public.groups WHERE name='G')),
  ('Corée du Sud', 'KR', 'https://flagcdn.com/kr.svg', (SELECT id FROM public.groups WHERE name='G')),
  ('USA', 'US', 'https://flagcdn.com/us.svg', (SELECT id FROM public.groups WHERE name='H')),
  ('Mexique', 'MX', 'https://flagcdn.com/mx.svg', (SELECT id FROM public.groups WHERE name='H'));

-- Stades exemple (USA, Canada, Mexique pour 2026)
INSERT INTO public.stadiums (name, city, country, capacity) VALUES
  ('SoFi Stadium', 'Los Angeles', 'USA', 70240),
  ('MetLife Stadium', 'New York', 'USA', 82500),
  ('AT&T Stadium', 'Dallas', 'USA', 80000),
  ('Hard Rock Stadium', 'Miami', 'USA', 65326),
  ('Estadio Azteca', 'Mexico', 'Mexique', 87523),
  ('BC Place', 'Vancouver', 'Canada', 54500);

-- Matchs exemple (10 premiers matchs de la phase de groupes)
INSERT INTO public.matches (match_number, phase, group_id, home_team_id, away_team_id, stadium_id, kickoff_time, status) VALUES
  (1, 'group',
    (SELECT id FROM public.groups WHERE name='A'),
    (SELECT id FROM public.teams WHERE country_code='FR'),
    (SELECT id FROM public.teams WHERE country_code='BR'),
    (SELECT id FROM public.stadiums WHERE name='MetLife Stadium'),
    '2026-06-11 21:00:00+00', 'upcoming'),
  (2, 'group',
    (SELECT id FROM public.groups WHERE name='B'),
    (SELECT id FROM public.teams WHERE country_code='AR'),
    (SELECT id FROM public.teams WHERE country_code='ES'),
    (SELECT id FROM public.stadiums WHERE name='SoFi Stadium'),
    '2026-06-12 18:00:00+00', 'upcoming'),
  (3, 'group',
    (SELECT id FROM public.groups WHERE name='C'),
    (SELECT id FROM public.teams WHERE country_code='GB-ENG'),
    (SELECT id FROM public.teams WHERE country_code='PT'),
    (SELECT id FROM public.stadiums WHERE name='AT&T Stadium'),
    '2026-06-13 21:00:00+00', 'upcoming'),
  (4, 'group',
    (SELECT id FROM public.groups WHERE name='D'),
    (SELECT id FROM public.teams WHERE country_code='DE'),
    (SELECT id FROM public.teams WHERE country_code='NL'),
    (SELECT id FROM public.stadiums WHERE name='Hard Rock Stadium'),
    '2026-06-14 18:00:00+00', 'upcoming'),
  (5, 'group',
    (SELECT id FROM public.groups WHERE name='E'),
    (SELECT id FROM public.teams WHERE country_code='BE'),
    (SELECT id FROM public.teams WHERE country_code='IT'),
    (SELECT id FROM public.stadiums WHERE name='Estadio Azteca'),
    '2026-06-15 21:00:00+00', 'upcoming');
