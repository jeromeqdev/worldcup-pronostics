// lib/utils.ts — Utilitaires partagés
import { type ClassValue, clsx } from "clsx";
import { format, formatDistanceToNow, isPast, isWithinInterval, subMinutes } from "date-fns";
import { fr } from "date-fns/locale";
import type { Match, MatchPhase, PredictedWinner } from "@/types";

// Fusion de classes CSS (équivalent cn de shadcn)
export function cn(...inputs: ClassValue[]) {
  return inputs
    .filter(Boolean)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
}

// Formatage des dates
export function formatKickoff(dateStr: string): string {
  return format(new Date(dateStr), "dd MMM yyyy • HH:mm", { locale: fr });
}

export function formatKickoffShort(dateStr: string): string {
  return format(new Date(dateStr), "dd/MM • HH:mm");
}

export function timeFromNow(dateStr: string): string {
  return formatDistanceToNow(new Date(dateStr), { locale: fr, addSuffix: true });
}

// Détermine si un match est pronosticable (avant coup d'envoi)
export function canPredict(match: Match): boolean {
  return match.status === "upcoming" && !isPast(new Date(match.kickoff_time));
}

// Détermine si un match est en cours (fenêtre ±2h autour du coup d'envoi)
export function isMatchLive(match: Match): boolean {
  if (match.status === "live") return true;
  const kickoff = new Date(match.kickoff_time);
  return isWithinInterval(new Date(), {
    start: kickoff,
    end: new Date(kickoff.getTime() + 2 * 60 * 60 * 1000),
  });
}

// Calcule le vainqueur prédit à partir de scores
export function getPredictedWinner(homeScore: number, awayScore: number): PredictedWinner {
  if (homeScore > awayScore) return "home";
  if (awayScore > homeScore) return "away";
  return "draw";
}

// Calcule les points d'un pronostic
export function calculatePoints(
  predHome: number,
  predAway: number,
  actualHome: number,
  actualAway: number
): number {
  if (predHome === actualHome && predAway === actualAway) return 5;
  const predWinner = getPredictedWinner(predHome, predAway);
  const actualWinner = getPredictedWinner(actualHome, actualAway);
  if (actualWinner === "draw" && predWinner === "draw") return 2;
  if (predWinner === actualWinner) return 3;
  return 0;
}

// Label de couleur selon les points
export function pointsColor(points: number): string {
  switch (points) {
    case 5: return "text-gold-400";
    case 3: return "text-pitch-500";
    case 2: return "text-blue-400";
    default: return "text-red-400";
  }
}

// Label de la phase en court
export const PHASE_SHORT: Record<MatchPhase, string> = {
  group: "Poules",
  round_of_16: "8e",
  quarter_final: "QF",
  semi_final: "SF",
  third_place: "3e",
  final: "Finale",
};

// URL du drapeau via flagcdn.com
export function flagUrl(countryCode: string): string {
  return `https://flagcdn.com/48x36/${countryCode.toLowerCase()}.png`;
}

// Rang avec suffixe (1er, 2e...)
export function rankLabel(rank: number): string {
  return rank === 1 ? "1er" : `${rank}e`;
}
